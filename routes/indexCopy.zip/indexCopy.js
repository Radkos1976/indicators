var express = require('express');
var router = express.Router();
var oledb = require('edge-oledb');
var NodeCache = require( "node-cache" );
var myCache = new NodeCache({ stdTTL: 800, checkperiod: 900 });

/* GET home page. */
router.get('/', function(req, res) {
  res.render('index4');
  });
router.get('/200SW', function(req, res) {
    res.render('index0');
  });
router.get('/500LI', function(req, res) {
    res.render('index1');
  });
router.get('/400ST', function(req, res) {
    res.render('index2');
  });
router.get('/ALL', function(req, res) {
      res.render('index3');
  });
  router.get('/AL', function(req, res) {
        res.render('index');
    });
router.get('/data/:id', function(req, res) {
  myCache.get(req.params.id, function( err, value ){
  if( !err ){
    var chk=true;
    if(value == undefined){
    var a=req.params.id.length-6;
    var dep=req.params.id.substring(1+a,6+a);
    var quer=IS_one(dep);
  	if(req.params.id.substring(0,1)==1 && a==0) {
      var options = {
      dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
      query : "SELECT b.descr,Format(a.valid_date,'yyyy-mm-dd') AS dzien, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100) AS wyda FROM wydaj as a,dpt AS b WHERE [a.END]=true and a.valid_date>now()-33 and ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null)  GROUP BY b.descr,Format(valid_date,'yyyy-mm-dd');"
      }
      console.log ("Ustawienia ACCESS")
      oledb(options, function( result ){
        if (!result.valid) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
          console.log ("Dane pobrane z ACCESS")
        var data= {
        labels : result.records.map(function(it){ return it.dzien}),
        title: "WYDAJNOŚĆ "  + result.records[0].descr,
        subtitle:"Dzienna",
        error : "No",
        datasets : [
          {
            fillColor : "rgba(255, 79, 48, 0.3)",
            strokeColor : "rgba(151,187,205,1)",
            pointColor : "rgba(220,220,220,1)",
            pointStrokeColor : "#fff",
            data : result.records.map(function(it){ return it.wyda})
          }
          ]
        }};
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });
  	   }else if (req.params.id.substring(0,1)==2 && a==0) {
      var options = {
      dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
      query : "select * from (SELECT top 13 b.descr, 'Tydz: ' & a.week AS week, Round((Sum(a.SUM_H_MADE_CORR)/Sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj AS a, dpt AS b WHERE [a.END]=True AND a.week>Format(Now()-180,'yyyy') & IIf(Len(Format(Now()-180,'ww'))=1,'0' & Format(Now()-180,'ww'),Format(Now()-180,'ww')) AND ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null)  GROUP BY b.descr, a.week order by a.week desc ) order by week;"
      }
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
          console.log ("Dane pobrane z ACCESS")
        var data= {
        labels : result.records.map(function(it){ return it.week}),
        title: "WYDAJNOŚĆ "  + result.records[0].descr,
        subtitle:"Tygodniowa",
        datasets : [
          {
            fillColor : "rgba(255, 79, 48, 0.3)",
            strokeColor : "rgba(151,187,205,1)",
            pointColor : "rgba(220,220,220,1)",
            pointStrokeColor : "#fff",
            data : result.records.map(function(it){ return it.wyda})
          }
        ]
      }};
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });
  	}else if (req.params.id.substring(0,1)==3 && a==0) {
      var options = {
        dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
        query : "SELECT b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a, dpt AS b WHERE [a.END]=true and a.Month>=Format(now()-365,'yyyymm') and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month asc;"
      }
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
      console.log ("Dane pobrane z ACCESS")
      var data= {
        labels : result.records.map(function(it){ return it.Moh}),
        title: "WYDAJNOŚĆ "  + result.records[0].descr,
        subtitle:"Miesięczna",
        datasets : [
          {
         fillColor : "rgba(255, 79, 48, 0.3)",
         strokeColor : "rgba(151,187,205,1)",
         pointColor : "rgba(220,220,220,1)",
         pointStrokeColor : "#fff",
         data : result.records.map(function(it){ return it.wyda})
        }
      ]
      }};
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });
    } else if (req.params.id.substring(0,2)==20 && a==1) {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "SELECT dpt.dp_ID,dpt.dester,r.WYDZ & r.DAY AS ID, r.MOnth, r.WEEk, format(r.DAY,'yyyy-mm-dd') as dzie, r.WYDZ, r.REFRDAT, max(TERMINOWOŚĆ.IL_PLAN) AS IL_PLAN, max(TERMINOWOŚĆ.MADE_ON_TIME) AS MADE_ON_TIME, min(TERMINOWOŚĆ.MADE_TOO_LATE) AS MADE_TOO_LATE, round(max(TERMINOWOŚĆ.MADE_ON_TIME)/max(TERMINOWOŚĆ.IL_PLAN)*100) AS TERMIN FROM (Select  q.MOnth,q.WEEk,wrk.DAY,wrk.WYDZ,max(MinimumOfREFR_DATE) as REFRDAT from (select * from  (SELECT TERMINOWOŚĆ.DAY, Left([REFR],8) AS Dzień, TERMINOWOŚĆ.WYDZ, Min(TERMINOWOŚĆ.REFR_DATE) AS MinimumOfREFR_DATE FROM TERMINOWOŚĆ GROUP BY TERMINOWOŚĆ.DAY, Left([REFR],8), TERMINOWOŚĆ.WYDZ, TERMINOWOŚĆ.TYP_RAP HAVING ((TERMINOWOŚĆ.TYP_RAP='POPRZEDNI DZIEŃ' and TERMINOWOŚĆ.WYDZ<>'MAG_WE') ) ORDER BY TERMINOWOŚĆ.DAY, Left([REFR],8), TERMINOWOŚĆ.WYDZ) union all (SELECT TERMINOWOŚĆ.DAY, Left([REFR],8) AS Dzień, TERMINOWOŚĆ.WYDZ, max(TERMINOWOŚĆ.REFR_DATE) AS MinimumOfREFR_DATE FROM TERMINOWOŚĆ GROUP BY TERMINOWOŚĆ.DAY, Left([REFR],8), TERMINOWOŚĆ.WYDZ, TERMINOWOŚĆ.TYP_RAP HAVING ((TERMINOWOŚĆ.TYP_RAP='BIEŻĄCY DZIEŃ' and TERMINOWOŚĆ.WYDZ='MAG_WE') )ORDER BY TERMINOWOŚĆ.DAY, Left([REFR],8), TERMINOWOŚĆ.WYDZ) ) as wrk,(select MOnth,WEEk,valid_date,department from wydaj group by MOnth,WEEk,valid_date,department union all select MOnth,WEEk,valid_date,'MAG_WE' as department from wydaj where department='400ST' group by MOnth,WEEk,valid_date ) as q where wrk.DAY=q.valid_date and wrk.WYDZ=q.department group by q.MOnth,q.WEEk,wrk.DAY,wrk.WYDZ)  AS r, TERMINOWOŚĆ ,dpt WHERE r.day>now()-33 and dpt.dpter=r.WYDZ and dpt.dp_id='" + dep + "' and r.REFRDAT=TERMINOWOŚĆ.REFR_DATE and r.wydz=TERMINOWOŚĆ.wydz GROUP BY dpt.dp_ID,dpt.dester,r.MOnth,r.WEEk,r.DAY, r.WYDZ, r.REFRDAT order by r.DAY asc ;"
                  }
          console.log ("Ustawienia ACCESS")
          oledb(options, function( result ){
            if (!result.valid) {
              console.log ("Błąd /" + result.error + "/");
               var data={
                error : "yes"
              };
              chk=false;
            } else {
              console.log ("Dane pobrane z ACCESS")
            var data= {
            labels : result.records.map(function(it){ return it.dzie}),
            title: "PROD. NA CZAS "  + result.records[0].dester,
            subtitle:"Dzienna",
            error : "No",
            datasets : [
              {
                fillColor : "rgba(180,152,197,0.5)",
                strokeColor : "rgba(151,187,205,1)",
                pointColor : "rgba(220,220,220,1)",
                pointStrokeColor : "#fff",
                data : result.records.map(function(it){ return it.TERMIN})
              }
              ]
            }};
          console.log ("Przypisano");
          if (chk) {myCache.set( req.params.id, data)};
          res.send( data );
          });
        } else if (req.params.id.substring(0,2)==21 && a==1) {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "select * from (SELECT top 13 dpt.dp_ID,dpt.dester, 'Tydz: ' & Termin_dzienna.WEEk AS WEEk, Termin_dzienna.WYDZ, Sum(Termin_dzienna.IL_PLAN) AS SumaOfIL_PLAN, Sum(Termin_dzienna.MADE_ON_TIME) AS SumaOfMADE_ON_TIME, Sum(Termin_dzienna.MADE_TOO_LATE) AS SumaOfMADE_TOO_LATE, round(Sum([MADE_ON_TIME])/Sum([IL_PLAN])*100,2) AS WYNIK_TERm FROM Termin_dzienna,dpt where dpt.dpter=Termin_dzienna.WYDZ and dpt.dp_id='" + dep + "' GROUP BY dpt.dp_ID,dpt.dester,Termin_dzienna.WEEk, Termin_dzienna.WYDZ order by Termin_dzienna.WEEk desc )  order by week asc"
                  }
          console.log ("Ustawienia ACCESS")
          oledb(options, function(result){
            if (!result.valid) {
              console.log ("Błąd /" + result.error + "/");
               var data={
                error : "yes"
              };
              chk=false;
            } else {
              console.log ("Dane pobrane z ACCESS")
            var data= {
            labels : result.records.map(function(it){ return it.WEEk}),
            title: "PROD. NA CZAS "  + result.records[0].dester,
            subtitle:"Tygodniowa",
            datasets : [
              {
                fillColor : "rgba(180,152,197,0.5)",
                strokeColor : "rgba(151,187,205,1)",
                pointColor : "rgba(220,220,220,1)",
                pointStrokeColor : "#fff",
                data : result.records.map(function(it){ return it.WYNIK_TERm})
              }
            ]
          }};
          console.log ("Przypisano");
          if (chk) {myCache.set( req.params.id, data)};
          res.send( data );
          });
      	} else if (req.params.id.substring(0,2)==16 && a==1) {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "SELECT b.dester as descr,Format(a.valid_date,'yyyy-mm-dd') as dzien,round((sum(a.wyk)/((sum(a.norma)+sum(c.sred))*7.5/8))*100) AS wyda FROM dpt AS b,(select valid_date,department,sum(SUM_H_MADE_NORM) as wyk,sum(WRK_norm) as norma from wydaj where [END]=true group by valid_date,department ) as a,(Select ID,wydz,mont,week,dat,sum(gr_sred) as sred from (select * from gr_sred union select Format(valid_date,'dd-mm-yyyy') & '_'  & department as ID, department as wydz,month as mont,week,valid_date as dat,0 as gr_sred from wydaj where valid_date>now()-33) group by  ID,wydz,mont,week,dat) as c WHERE a.valid_date>now()-33 and ((b.dp_id)='" + dep + "') AND iif((b.dpter='ALL' or b.dpter='MAG_WE'),a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department=b.dpter) and  (c.ID=Format(a.valid_date,'dd-mm-yyyy') & '_'  & a.department) GROUP BY b.dester ,Format(a.valid_date,'yyyy-mm-dd') order by Format(a.valid_date,'yyyy-mm-dd');"                }
          console.log ("Ustawienia ACCESS")
          oledb(options, function( result ){
            if (!result.valid) {
              console.log ("Błąd /" + result.error + "/");
               var data={
                error : "yes"
              };
              chk=false;
            } else {
              console.log ("Dane pobrane z ACCESS")
            var data= {
            labels : result.records.map(function(it){ return it.dzien}),
            title: "WYDAJNOŚĆ NETTO "  + result.records[0].descr,
            subtitle:"Dzienna",
            error : "No",
            datasets : [
              {
                fillColor : "rgba(255, 157, 44, 0.3)",
                strokeColor : "rgba(151,187,205,1)",
                pointColor : "rgba(220,220,220,1)",
                pointStrokeColor : "#fff",
                data : result.records.map(function(it){ return it.wyda})
              }
              ]
            }};
          console.log ("Przypisano");
          if (chk) {myCache.set( req.params.id, data)};
          res.send( data );
          });
        }else if (req.params.id.substring(0,2)==17 && a==1) {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "select * from (SELECT top 13 b.dester as descr,'Tydz: ' & a.week AS week,round((sum(a.wyk)/((sum(a.norma)+sum(c.sred))*7.5/8))*100,2) AS wyda FROM dpt AS b,(select valid_date,week,department,sum(SUM_H_MADE_NORM) as wyk,sum(WRK_norm) as norma from wydaj where [END]=true group by valid_date,week,department ) as a,(Select ID,wydz,mont,week,dat,sum(gr_sred) as sred from (select * from gr_sred union select Format(valid_date,'dd-mm-yyyy') & '_'  & department as ID, department as wydz,month as mont,week,valid_date as dat,0 as gr_sred from wydaj where valid_date>now()-200) group by  ID,wydz,mont,week,dat) as c WHERE a.valid_date>now()-200 and ((b.dp_id)='" + dep + "') AND iif((b.dpter='ALL' or b.dpter='MAG_WE'),a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department=b.dpter) and  (c.ID=Format(a.valid_date,'dd-mm-yyyy') & '_'  & a.department) GROUP BY b.dester ,'Tydz: ' & a.week order by 'Tydz: ' & a.week desc) order by week asc;"
                  }
          console.log ("Ustawienia ACCESS")
          oledb(options, function(result){
            if (!result.valid) {
              console.log ("Błąd /" + result.error + "/" );
               var data={
                error : "yes"
              };
              chk=false;
            } else {
              console.log ("Dane pobrane z ACCESS")
            var data= {
            labels : result.records.map(function(it){ return it.week}),
            title: "WYDAJNOŚĆ NETTO "  + result.records[0].descr,
            subtitle:"Tygodniowa",
            datasets : [
              {
                fillColor : "rgba(255, 157, 44, 0.3)",
                strokeColor : "rgba(151,187,205,1)",
                pointColor : "rgba(220,220,220,1)",
                pointStrokeColor : "#fff",
                data : result.records.map(function(it){ return it.wyda})
              }
            ]
          }};
          console.log ("Przypisano");
          if (chk) {myCache.set( req.params.id, data)};
          res.send( data );
          });
      	}else if (req.params.id.substring(0,2)==18 && a==1) {
          var options = {
            dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
            query : "SELECT b.dester as descr,Format(a.valid_date,'yyyymm') as Mont,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.wyk)/((sum(a.norma)+sum(c.sred))*7.5/8))*100,2) AS wyda FROM dpt AS b,(select valid_date,department,sum(SUM_H_MADE_NORM) as wyk,sum(WRK_norm) as norma from wydaj where [END]=true group by valid_date,department ) as a,(Select ID,wydz,mont,week,dat,sum(gr_sred) as sred from (select * from gr_sred union select Format(valid_date,'dd-mm-yyyy') & '_'  & department as ID, department as wydz,month as mont,week,valid_date as dat,0 as gr_sred from wydaj where valid_date>now()-365) group by  ID,wydz,mont,week,dat) as c WHERE a.valid_date>now()-365 and ((b.dp_id)='" + dep + "') AND iif((b.dpter='ALL' or b.dpter='MAG_WE'),a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department=b.dpter) and  (c.ID=Format(a.valid_date,'dd-mm-yyyy') & '_'  & a.department) GROUP BY b.dester ,Format(a.valid_date,'yyyymm') ,Format(a.valid_date,'mmmm yyyyr') order by Format(a.valid_date,'yyyymm');"
                              }
          console.log ("Ustawienia ACCESS")
          oledb(options, function(result){
            if (!result.valid) {
              console.log ("Błąd /" + result.error + "/");
               var data={
                error : "yes"
              };
              chk=false;
            } else {
          console.log ("Dane pobrane z ACCESS")
          var data= {
            labels : result.records.map(function(it){ return it.Moh}),
            title: "WYDAJNOŚĆ NETTO "  + result.records[0].descr,
            subtitle:"Miesięczna",
            datasets : [
              {
             fillColor : "rgba(255, 157, 44, 0.3)",
             strokeColor : "rgba(151,187,205,1)",
             pointColor : "rgba(220,220,220,1)",
             pointStrokeColor : "#fff",
             data : result.records.map(function(it){ return it.wyda})
            }
          ]
          }};
          console.log ("Przypisano");
          if (chk) {myCache.set( req.params.id, data)};
          res.send( data );
          });
        } else if (req.params.id.substring(0,2)==22 && a==1) {
          var options = {
            dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
            query : "SELECT dpt.dp_ID,dpt.dester,Termin_dzienna.MOnth,Format(Termin_dzienna.day,'mmmm yyyyr') as Moh, Termin_dzienna.WYDZ, Sum(Termin_dzienna.IL_PLAN) AS SumaOfIL_PLAN, Sum(Termin_dzienna.MADE_ON_TIME) AS SumaOfMADE_ON_TIME, Sum(Termin_dzienna.MADE_TOO_LATE) AS SumaOfMADE_TOO_LATE, round(Sum([MADE_ON_TIME])/Sum([IL_PLAN])*100,2) AS WYNIK_TERm FROM Termin_dzienna,dpt where Termin_dzienna.MOnth>=Format(now()-365,'yyyymm') and dpt.dpter= Termin_dzienna.WYDZ and dpt.dp_id='" + dep + "' GROUP BY dpt.dp_ID,dpt.dester,Termin_dzienna.MOnth, Format(Termin_dzienna.day,'mmmm yyyyr'),Termin_dzienna.WYDZ order by month asc;"
                    }
          console.log ("Ustawienia ACCESS")
          oledb(options, function(result){
            if (!result.valid) {
              console.log ("Błąd /" + result.error + "/");
               var data={
                error : "yes"
              };
              chk=false;
            } else {
          console.log ("Dane pobrane z ACCESS")
          var data= {
            labels : result.records.map(function(it){ return it.Moh}),
            title: "PROD. NA CZAS "  + result.records[0].dester,
            subtitle:"Miesięczna",
            datasets : [
              {
             fillColor : "rgba(180,152,197,0.5)",
             strokeColor : "rgba(151,187,205,1)",
             pointColor : "rgba(220,220,220,1)",
             pointStrokeColor : "#fff",
             data : result.records.map(function(it){ return it.WYNIK_TERm})
            }
          ]
          }};
          console.log ("Przypisano");
          if (chk) {myCache.set( req.params.id, data)};
          res.send( data );
          });
        } else if (req.params.id.substring(0,1)==5 && a==0) {
      var options = {
        dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
        query : "SELECT b.descr, Format(a.valid_date,'yyyy-mm-dd') as dzien, round(a.wyn*100,2) AS Wynik FROM (SELECT b.valid_date,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a,(SELECT valid_date, week FROM wydaj where valid_date>=(now()-33) GROUP BY valid_date, week) AS b WHERE a.tydzień=b.week GROUP BY b.valid_date,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b WHERE  a.mpk=b.mpk order by Format(a.valid_date,'yyyy-mm-dd')"
            }
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid || quer==1) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
      console.log ("Dane pobrane z ACCESS")
      var data= {
        labels : result.records.map(function(it){ return it.dzien}),
        title: "WYNIKI 5-S "  + result.records[0].descr,
        subtitle:"Dzienne",
        datasets : [
          {
         fillColor : "rgba(151,187,205,0.5)",
         strokeColor : "rgba(151,187,205,1)",
         pointColor : "rgba(220,220,220,1)",
         pointStrokeColor : "#fff",
         data : result.records.map(function(it){ return it.Wynik})
        }
      ]
      }};
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });
    } else if (req.params.id.substring(0,1)==6 && a==0) {
      var options = {
        dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
        query : "select * from (SELECT top 13 b.descr, 'Tydz: ' & a.tydzień as week, round(a.wyn*100,2) AS Wynik FROM (SELECT tydzień, mid(mpk,1,4) as mpk1, avg(wynik) AS wyn FROM wynik5s where tydzień>Format(Now()-180,'yyyy') & IIf(Len(Format(Now()-180,'ww'))=1,'0' & Format(Now()-180,'ww'),Format(Now()-180,'ww')) GROUP BY tydzień, mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b WHERE a.mpk1=b.mpk order by a.tydzień desc) order by week;"
      }
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid || quer==1) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
      console.log ("Dane pobrane z ACCESS")
      var data= {
        labels : result.records.map(function(it){ return it.week}),
        title: "WYNIKI 5-S "  + result.records[0].descr,
        subtitle:"Tygodniowe",
        datasets : [
          {
         fillColor : "rgba(151,187,205,0.5)",
         strokeColor : "rgba(151,187,205,1)",
         pointColor : "rgba(220,220,220,1)",
         pointStrokeColor : "#fff",
         data : result.records.map(function(it){return it.Wynik})
        }
      ]
      };
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      }});
    }else if (req.params.id.substring(0,1)==4 && a==0) {
      if (quer==2) {
        var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "Select ta.poziom5s,ta.poziom,ta.prog,ta.wydaj from (SELECT top 1 b.descr ,cdbl(dateserial(mid(a.month,1,4),mid(a.month,5,2),1)) as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>format(now()-60,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b WHERE  a.mpk=b.mpk order by a.month desc) as Act,(select * from (select poziom5s,poziom,prog,wydaj,cdbl(Ważny_OD) as OD,cdbl(Ważny_DO) as DO from progi where dp_id='" + dep + "' and prog<>0) union (select '<' & poziom5s ,0 as poziom,0 as prog , '<' & wydaj,cdbl(Ważny_OD) as OD,cdbl(Ważny_do) as DO  from progi where prog=1 and  dp_id='" + dep + "')) as ta where mont BETWEEN  ta.od and ta.do order by prog;"
                };
      } else {
        if (quer==1) {
          var options = {
            dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
            query : "Select ta.poziom,ta.prog,ta.wydaj from (SELECT top 1 b.descr ,cdbl(dateserial(mid(a.month,1,4),mid(a.month,5,2),1)) as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>format(now()-60,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='400S0' ) AS b WHERE  a.mpk=b.mpk order by a.month desc) as Act,(select * from (select poziom,prog,wydaj,cdbl(Ważny_OD) as OD,cdbl(Ważny_DO) as DO from progi where dp_id='" + dep + "' and prog<>0) union (select 0 as poziom,0 as prog , '<' & wydaj,cdbl(Ważny_OD) as OD,cdbl(Ważny_DO) as DO  from progi where prog=1 and  dp_id='" + dep + "') order by prog) as ta where mont BETWEEN  ta.od and ta.do order by prog;"
          };
        } else {
          var options = {
            dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
            query : "Select ta.brak as braki,ta.poziom5s,ta.poziom,ta.prog,ta.wydaj from (SELECT top 1 b.descr ,cdbl(dateserial(mid(a.month,1,4),mid(a.month,5,2),1)) as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>format(now()-60,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b WHERE  a.mpk=b.mpk order by a.month desc) as Act,(select * from (select format(braki,'###0.000') as brak,poziom5s,poziom,prog,wydaj,cdbl(Ważny_OD) as OD,cdbl(Ważny_DO) as DO from progi where dp_id='" + dep + "' and prog<>0) union (select '>' & format(braki,'###0.000'), '<' & poziom5s ,0 as poziom,0 as prog , '<' & wydaj,cdbl(Ważny_OD) as OD,cdbl(Ważny_DO) as DO  from progi where prog=1 and  dp_id='" + dep + "') order by prog) as ta where mont BETWEEN  ta.od and ta.do order by prog;"
          };
        };
      };
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result) {
        if (!result.valid) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
      console.log ("Dane pobrane z ACCESS")
    if (quer==2) {
      var data= {
        title : "TABELA CELÓW DLA OBSZARU",
        table :[
          result.records.map(function(it){ return it.prog}),
          result.records.map(function(it){ return it.wydaj}),
          result.records.map(function(it){ return it.poziom5s}),
          result.records.map(function(it){ return it.poziom}),
        ],
        columns : ["Próg","Wydajność","5-S","Poziom"],
        waga : ["Waga","75%","25%"],
      };
        } else {
        if (quer==1) {
          var data= {
            title : "TABELA CELÓW DLA OBSZARU",
            table :[
              result.records.map(function(it){ return it.prog}),
              result.records.map(function(it){ return it.wydaj}),
              result.records.map(function(it){ return it.poziom}),
            ],
            columns : ["Próg","Wydajność","Poziom"],
            waga : ["Waga","100%"],
        };
      } else {
        var data= {
          title : "TABELA CELÓW DLA OBSZARU",
          table :[
            result.records.map(function(it){ return it.prog}),
            result.records.map(function(it){ return it.wydaj}),
            result.records.map(function(it){ return it.poziom5s}),
            result.records.map(function(it){ return it.braki}),
            result.records.map(function(it){ return it.poziom}),
          ],
          columns : ["Próg","Wydajność","5-S","Braki","Poziom"],
          waga : ["Waga","60%","25%","15%"],
          };
        };
        }};
      console.log ("Przypisano "+ dep);
      if (chk)  {myCache.set( req.params.id, data)};
      res.send( data );
      });
    } else if (req.params.id.substring(0,1)==7 && a==0) {
      var options = {
        dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
        query : "SELECT b.descr, Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>=Format(now()-365,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b WHERE  a.mpk=b.mpk order by a.month"
      }
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid || quer==1) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
      console.log ("Dane pobrane z ACCESS")
      var data= {
        labels : result.records.map(function(it){ return it.mont}),
        title: "WYNIKI 5-S "  + result.records[0].descr,
        subtitle:"Miesięczne",
        datasets : [
          {
         fillColor : "rgba(151,187,205,0.5)",
         strokeColor : "rgba(151,187,205,1)",
         pointColor : "rgba(220,220,220,1)",
         pointStrokeColor : "#fff",
         data : result.records.map(function(it){ return it.Wynik})
        }
      ]
      }};
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });
    }else if(req.params.id.substring(0,2)==10 && a==1) {
      var options = {
      dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
      query : "SELECT top 1 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a, dpt AS b WHERE a.valid_date>now()-40 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc;"
      }
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
          console.log ("Dane pobrane z ACCESS")
        var data={
        title: "WYDAJNOŚĆ",
        subtitle: result.records[0].descr + " " + result.records[0].Moh.toUpperCase(),
        value : result.records[0].wyda,
        Mnt : result.records[0].Moh.toUpperCase(),
        color: ["rgba(255, 79, 48, 0.3)"],
        jedn: '%',
      }};
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });
    }else if (req.params.id.substring(0,2)==13 && a==1) {
      console.log ("Przetwarzanie")
      if (quer==2) {
       var options = {
        dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
        query : "SELECT a.descr, a.mont, max(b.poziom)*0.25+max(d.poziom)*0.75*iif(max(b.poziom)=0 or max(d.poziom)=0,0.5,1) AS Wynik, max(b.poziom) AS five_S, max(d.poziom) AS wyd, c.wyda, a.wynik AS wys, b.jednostka, a.month FROM (SELECT top 13 b.descr,a.month,Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>format(now()-400,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b  WHERE  a.mpk=b.mpk order by a.month desc)  AS a, (SELECT top 13 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a, dpt AS b WHERE a.valid_date>now()-400 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc)  AS c, (select Poziom5s,Poziom,jednostka,ważny_od,ważny_do from progi where dp_id='" + dep + "')  AS b, (select wydaj,Poziom,ważny_od,ważny_do from progi where dp_id='" + dep + "')  AS d WHERE a.month=c.month and (a.wynik>=b.poziom5S and (dateserial(left(a.month,4),mid(a.month,5,2),1) between  b.ważny_od and b.ważny_do) )  and  (c.wyda>=d.wydaj  and (dateserial(left(a.month,4),mid(a.month,5,2),1) between  d.ważny_od and d.ważny_do)) GROUP BY a.descr, a.mont, c.wyda, a.wynik, b.jednostka, a.month ORDER BY a.month asc;"
        }
      } else {
        if (quer==1) {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "select c.descr,c.moh,max(d.poziom) as Wynik,c.wyda,d.jednostka,c.month from (SELECT top 13 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a,dpt AS b WHERE a.valid_date>now()-400 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc) as c,(select wydaj,Poziom,jednostka,ważny_od,ważny_do from progi where dp_id='" + dep + "') as d where  c.wyda>=d.wydaj and dateserial(left(c.month,4),mid(c.month,5,2),1) between d.ważny_od and d.ważny_do group by  c.descr,c.moh,c.wyda,d.jednostka,c.month order by c.month;"
          };
        } else {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "select a.descr,a.mont,max(b.poziom)*0.25+max(d.poziom)*0.6+max(f.poziom)*0.15*iif(max(b.poziom)=0 or max(d.poziom)=0 or max(f.poziom)=0,0.5,1) as Wynik,max(b.poziom) as five_S,max(d.poziom) as wyd,max(f.poziom) as p_brak,c.wyda,a.wynik as wys,e.braki,b.jednostka,a.month from (SELECT top 13 b.descr,a.month,Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a,(SELECT month, week FROM wydaj where month>format(now()-400,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b  WHERE  a.mpk=b.mpk order by a.month desc) as a,(SELECT top 13 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a,dpt AS b WHERE a.valid_date>now()-400 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc) as c,(select Poziom5s,Poziom,jednostka from progi where dp_id='" + dep + "') as b,(select wydaj,Poziom from progi where dp_id='" + dep + "') as d,(SELECT top 13 b.descr,a.month,Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.WSp_BRK,4) AS Braki FROM (SELECT month,mpk,WSp_BRK FROM MGWiS AS a),(select * from dpt where dp_id='" + dep + "' ) AS b  WHERE  a.mpk=b.mpk order by a.month desc) as e,(select braki,Poziom from progi where dp_id='" + dep + "') as f  where a.month=c.month and e.month=c.month and a.wynik>=b.poziom5S and  c.wyda>=d.wydaj and e.braki<=f.braki group by a.descr,a.mont,c.wyda,a.wynik,e.braki,b.jednostka,a.month order by a.month asc;"
        }
        };
      };
      console.log ("Ustawienia ACCESS")
      oledb(options, function(result){
        if (!result.valid) {
          console.log ("Błąd /" + result.error + "/");
           var data={
            error : "yes"
          };
          chk=false;
        } else {
      console.log ("Dane pobrane z ACCESS")
      if (quer==2) {
        var data= {
          labels : result.records.map(function(it){ return it.mont}),
          jedn: result.records[0].jednostka,
          title: "WYNIKI PREMII DLA DZIAŁU "  + result.records[0].descr,
          title1: "WYDAJNOŚĆ " + result.records[0].descr,
          title2: "WYNIKI 5-S "  + result.records[0].descr,
          subtitle:"Miesięcznie",
          datasets : [
            {
           fillColor : "rgba(148,176,76,0.5)",
           strokeColor : "rgba(151,187,205,1)",
           pointColor : "rgba(220,220,220,1)",
           pointStrokeColor : "#fff",
           data : result.records.map(function(it){ return it.Wynik})
            }
          ],
          datasets1 : [
            {
            fillColor : "rgba(255, 79, 48, 0.3)",
            strokeColor : "rgba(151,187,205,1)",
            pointColor : "rgba(220,220,220,1)",
            pointStrokeColor : "#fff",
            data : result.records.map(function(it){ return it.wyda})
            }
          ],
          datasets2 : [
            {
           fillColor : "rgba(151,187,205,0.5)",
           strokeColor : "rgba(151,187,205,1)",
           pointColor : "rgba(220,220,220,1)",
           pointStrokeColor : "#fff",
           data : result.records.map(function(it){ return it.wys})
            }
          ]
          }

      } else {
        if (quer==1) {
          var data= {
            labels : result.records.map(function(it){ return it.moh}),
            jedn: result.records[0].jednostka,
            title: "WYNIKI PREMII DLA DZIAŁU "  + result.records[0].descr,
            title1: "WYDAJNOŚĆ " + result.records[0].descr,
            subtitle:"Miesięcznie",
            datasets : [
              {
             fillColor : "rgba(148,176,76,0.5)",
             strokeColor : "rgba(151,187,205,1)",
             pointColor : "rgba(220,220,220,1)",
             pointStrokeColor : "#fff",
             data : result.records.map(function(it){ return it.Wynik})
              }
            ],
            datasets1 : [
              {
              fillColor : "rgba(255, 79, 48, 0.3)",
              strokeColor : "rgba(151,187,205,1)",
              pointColor : "rgba(220,220,220,1)",
              pointStrokeColor : "#fff",
              data : result.records.map(function(it){ return it.wyda})
              }
            ]
            }
        } else {
          var data= {
            labels : result.records.map(function(it){ return it.mont}),
            jedn: result.records[0].jednostka,
            title: "WYNIKI PREMII DLA DZIAŁU "  + result.records[0].descr,
            title1: "WYDAJNOŚĆ " + result.records[0].descr,
            title2: "WYNIKI 5-S "  + result.records[0].descr,
            title3: "BRAKI /REKLAMACJE "  + result.records[0].descr,
            subtitle:"Miesięcznie",
            datasets : [
              {
             fillColor : "rgba(148,176,76,0.5)",
             strokeColor : "rgba(151,187,205,1)",
             pointColor : "rgba(220,220,220,1)",
             pointStrokeColor : "#fff",
             data : result.records.map(function(it){ return it.Wynik})
              }
            ],
            datasets1 : [
              {
              fillColor : "rgba(255, 79, 48, 0.3)",
              strokeColor : "rgba(151,187,205,1)",
              pointColor : "rgba(220,220,220,1)",
              pointStrokeColor : "#fff",
              data : result.records.map(function(it){ return it.wyda})
              }
            ],
            datasets2 : [
              {
             fillColor : "rgba(151,187,205,0.5)",
             strokeColor : "rgba(151,187,205,1)",
             pointColor : "rgba(220,220,220,1)",
             pointStrokeColor : "#fff",
             data : result.records.map(function(it){ return it.wys})
              }
            ],
            datasets3 : [
              {
             fillColor : "rgba(194,152,44,0.5)",
             strokeColor : "rgba(151,187,205,1)",
             pointColor : "rgba(220,220,220,1)",
             pointStrokeColor : "#fff",
             data : result.records.map(function(it){ return it.braki})
              }
            ]
            };
          };
        };
      };
      console.log ("Przypisano");
      if (chk) {myCache.set( req.params.id, data)};
      res.send( data );
      });

    }else if(req.params.id.substring(0,2)==14 && a==1) {
       var options = {
       dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
       query : "SELECT top 1 dpt.dp_ID,dpt.dester,Termin_dzienna.MOnth as mont,Format(Termin_dzienna.day,'mmmm yyyyr') as Moh, Termin_dzienna.WYDZ, Sum(Termin_dzienna.IL_PLAN) AS SumaOfIL_PLAN, Sum(Termin_dzienna.MADE_ON_TIME) AS SumaOfMADE_ON_TIME, Sum(Termin_dzienna.MADE_TOO_LATE) AS SumaOfMADE_TOO_LATE, round(Sum([MADE_ON_TIME])/Sum([IL_PLAN])*100,2) AS WYNIK_TERm FROM Termin_dzienna,dpt where Termin_dzienna.MOnth>=Format(now()-365,'yyyymm') and dpt.dpter= Termin_dzienna.WYDZ and dpt.dp_id='" + dep + "' GROUP BY dpt.dp_ID,dpt.dester,Termin_dzienna.MOnth, Format(Termin_dzienna.day,'mmmm yyyyr'),Termin_dzienna.WYDZ order by month desc"
       }
       console.log ("Ustawienia ACCESS")
       oledb(options, function(result){
         if (!result.valid || quer==1) {
           console.log ("Błąd /" + result.error + "/");
            var data={
             error : "yes"
           };
           chk=false;
         } else {
           console.log ("Dane pobrane z ACCESS")
         var data={
         title: "PRODUKCJA NA CZAS",
         subtitle: result.records[0].dester + " " + result.records[0].Moh.toUpperCase(),
         value : result.records[0].WYNIK_TERm,
         Mnt : result.records[0].Moh.toUpperCase(),
         color: ["rgba(180,152,197,0.5)"],
         jedn: '%',
       }};
       console.log ("Przypisano");
       if (chk) {myCache.set( req.params.id, data)};
       res.send( data );
       });
   	 } else if(req.params.id.substring(0,2)==11 && a==1) {
       var options = {
       dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
       query : "SELECT top 1 b.descr, Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>format(now()-60,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b WHERE  a.mpk=b.mpk order by a.month desc;"
       }
       console.log ("Ustawienia ACCESS")
       oledb(options, function(result){
         if (!result.valid || quer==1) {
           console.log ("Błąd /" + result.error + "/");
            var data={
             error : "yes"
           };
           chk=false;
         } else {
           console.log ("Dane pobrane z ACCESS")
         var data={
         title: "WYNIK 5-S",
         subtitle: result.records[0].descr + " " + result.records[0].mont.toUpperCase(),
         value : result.records[0].Wynik,
         Mnt : result.records[0].mont.toUpperCase(),
         color: ["rgba(151,187,205,0.5)"],
         jedn: '%',
       }};
       console.log ("Przypisano");
       if (chk) {myCache.set( req.params.id, data)};
       res.send( data );
       });
   	 } else if (req.params.id.substring(0,2)==12 && a==1) {
       if (quer==2) {
        var options = {
        dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
        query : "select a.descr,a.mont,max(b.poziom)*0.25+max(d.poziom)*0.75*iif(max(b.poziom)=0 or max(d.poziom)=0,0.5,1) as Wynik,max(b.poziom) as five_S,max(d.poziom) as wyd,c.wyda,a.wynik as wys,b.jednostka,a.month from (SELECT top 2 b.descr,a.month,Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a, (SELECT month, week FROM wydaj where month>format(now()-60,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b  WHERE  a.mpk=b.mpk order by a.month desc) as a,(SELECT top 2 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a, dpt AS b WHERE a.valid_date>now()-60 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc) as c,(select Poziom5s,Poziom,jednostka,ważny_od,ważny_do from progi where dp_id='" + dep + "') as b,(select wydaj,Poziom,ważny_od,ważny_do from progi where dp_id='" + dep + "') as d  where a.month=c.month and (a.wynik>=b.poziom5S and (dateserial(left(a.month,4),mid(a.month,5,2),1) between  b.ważny_od and b.ważny_do) )  and  (c.wyda>=d.wydaj  and (dateserial(left(a.month,4),mid(a.month,5,2),1) between  d.ważny_od and d.ważny_do)) group by a.descr,a.mont,c.wyda,a.wynik,b.jednostka,a.month order by a.month desc; "
          };
      } else {
        if (quer==1) {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "select c.descr,c.moh,max(d.poziom) as Wynik,c.wyda,d.jednostka,c.month from (SELECT top 2 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a,dpt AS b WHERE a.valid_date>now()-60 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc) as c,(select wydaj,Poziom,jednostka,ważny_od,ważny_do from progi where dp_id='" + dep + "') as d where  c.wyda>=d.wydaj and dateserial(left(c.month,4),mid(c.month,5,2),1) between d.ważny_od and d.ważny_do group by  c.descr,c.moh,c.wyda,d.jednostka,c.month order by c.month desc;"
          };
        } else {
          var options = {
          dsn :  "Provider=Microsoft.ace.OLEDB.12.0;Data Source=WYDAJ.accdb;Persist Security Info=False;Mode=Read;",
          query : "select a.descr,a.mont,max(b.poziom)*0.25+max(d.poziom)*0.6+max(f.poziom)*0.15*iif(max(b.poziom)=0 or max(d.poziom)=0 or max(f.poziom)=0,0.5,1) as Wynik,max(b.poziom) as five_S,max(d.poziom) as wyd,max(f.poziom) as p_brak,c.wyda,a.wynik as wys,e.braki,b.jednostka,a.month from (SELECT top 2 b.descr,a.month,Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.wyn*100,2) AS Wynik FROM (SELECT b.month,mid(a.mpk,1,4) as mpk, avg(a.wynik) AS wyn FROM wynik5s AS a,(SELECT month, week FROM wydaj where month>format(now()-60,'yyyymm') GROUP BY month, week)  AS b WHERE a.tydzień=b.week GROUP BY b.month,mpk)  AS a ,(select * from dpt where dp_id='" + dep + "' ) AS b  WHERE  a.mpk=b.mpk order by a.month desc) as a,(SELECT top 2 b.descr,a.Month,Format(a.valid_date,'mmmm yyyyr') as Moh, round((sum(a.SUM_H_MADE_CORR)/sum(a.WRK_H_SUM*7.5/8))*100,2) AS wyda FROM wydaj as a,dpt AS b WHERE a.valid_date>now()-60 and [a.END]=true and  ((b.dp_id)='" + dep + "') AND iif(b.department,a.department in (select department from dept where dp_id='" + dep + "' group by department),a.department is not null) and iif(b.workcnt,a.work_center in (select workcnt from dept where dp_id='" + dep + "' group by workcnt),a.work_center is not null) and iif(b.notworkcnt,a.work_center not in (select notworkcnt from dept where dp_id='" + dep + "' group by notworkcnt),a.work_center is not null) GROUP BY b.descr,a.month ,Format(a.valid_date,'mmmm yyyyr') order by a.month desc) as c,(select Poziom5s,Poziom,jednostka from progi where dp_id='" + dep + "') as b,(select wydaj,Poziom from progi where dp_id='" + dep + "') as d,(SELECT top 2 b.descr,a.month,Format(mid(a.month,5,2) & '-01-' & mid(a.month,1,4),'mmmm yyyyr') as mont, round(a.WSp_BRK,4) AS Braki FROM (SELECT month,mpk,WSp_BRK FROM MGWiS AS a),(select * from dpt where dp_id='" + dep + "' ) AS b  WHERE  a.mpk=b.mpk order by a.month desc) as e,(select braki,Poziom from progi where dp_id='" + dep + "') as f  where a.month=c.month and e.month=c.month and a.wynik>=b.poziom5S and  c.wyda>=d.wydaj and e.braki<=f.braki group by a.descr,a.mont,c.wyda,a.wynik,e.braki,b.jednostka,a.month order by a.month desc;"
        }
        };
      };
        console.log ("Ustawienia ACCESS")
        oledb(options, function(result){
          if (!result.valid) {
            console.log ("Błąd /" + result.error + "/");
             var data={
              error : "yes"
            };
            chk=false;
          } else {
            console.log ("Dane pobrane z ACCESS")

            var colr=["rgba(215, 84, 44, 0.9)"]
            if (result.records[0].jednostka=='%') {
              if (result.records[0].Wynik>100) {
                var colr=["rgba(148, 176, 76, 0.9)"]};
            } else {if (result.records[0].Wynik>430) {
              var colr=["rgba(148, 176, 76, 0.9)"]}};
        if (quer==2)  {
          var data={
          title: "WYNIK PREMII DLA DZIAŁU",
          subtitle: result.records[0].descr + " " + result.records[0].mont.toUpperCase(),
          value : result.records[0].Wynik,
          Mnt : result.records[0].mont.toUpperCase(),
          five_S : result.records[0].five_S,
          Wyd : result.records[0].wyd,
          wydajnosc : result.records[0].wyda,
          s : result.records[0].wys,
          color: colr,
          jedn: result.records[0].jednostka,
        }
      } else {
        if (quer==1) {
          var data={
          title: "WYNIK PREMII DLA DZIAŁU",
          subtitle: result.records[0].descr + " " + result.records[0].moh.toUpperCase(),
          value : result.records[0].Wynik,
          Mnt : result.records[0].moh.toUpperCase(),
          Wyd : result.records[0].Wynik,
          wydajnosc : result.records[0].wyda,
          color: colr,
          jedn: result.records[0].jednostka,
          }
          } else {
          var data={
          title: "WYNIK PREMII DLA DZIAŁU",
          subtitle: result.records[0].descr + " " + result.records[0].mont.toUpperCase(),
          value : result.records[0].Wynik,
          Mnt : result.records[0].mont.toUpperCase(),
          five_S : result.records[0].five_S,
          Wyd : result.records[0].wyd,
          wydajnosc : result.records[0].wyda,
          s : result.records[0].wys,
          p_BRAK : result.records[0].p_brak,
          braki: result.records[0].braki,
          color: colr,
          jedn: result.records[0].jednostka,
        }
      };
      };
        console.log ("Przypisano");
        if (chk) {myCache.set( req.params.id, data)};
        res.send( data );
          }
        });
    	 }else {
      var data;
  		data = {
  			labels : ["July","August","September","October","November","December"],
        title: "TEST",
        subtitle:"OVERFLOW",
  			datasets : [
  				{
  					fillColor : "rgba(151,187,205,0.5)",
  					strokeColor : "rgba(151,187,205,1)",
  					pointColor : "rgba(151,187,205,1)",
  					pointStrokeColor : "#fff",
  					data : [28,48,40,19,96,27]
  				}
  			]
  		};
      console.log ("Wysyłam JSON")
      myCache.set( req.params.id, data);
      res.send( data );
    }

    }else{
      console.log ("Cache");
      res.send(value);
    }
   }
 });
    });
    function IS_one (depar) {
      var ar=';300M1;000M1;200S3;500L4;500L3;400S3;600W0;100K0;000M0';
      if (ar.indexOf(depar)!=-1) {
        return 1;
      } else {
        var as =';600M1;600M0;300M0';
        if (as.indexOf(depar)!=-1) {
          return 3;
      } else {
        return 2;
      };
    };
    }

module.exports = router;
